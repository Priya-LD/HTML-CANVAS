function setLocal(){
    if(typeof(Storage)!=='undefined'){
        localStorage.setItem("firstname","Pikachu");
        localStorage.setItem("secondname","Reynolds");
    }
}

function getLocal(){
    if(typeof(Storage)!=='undefined'){
        console.log(localStorage.getItem("firstname"));
        console.log(localStorage.getItem("secondname"));

    }
}
function removeLocal(){
    if(typeof(Storage)!=='undefined'){
        console.log(localStorage.removeItem("firstname"));
        console.log(localStorage.removeItem("secondname"));

    }
}

function setSession(){
    if(typeof(Storage)!=='undefined'){
        sessionStorage.setItem("firstname","Pikachu");
        sessionStorage.setItem("secondname","Reynolds");
    }
}

function getSession(){
    if(typeof(Storage)!=='undefined'){
        console.log(sessionStorage.getItem("firstname"));
        console.log(sessionStorage.getItem("secondname"));

    }
}

function removeSession(){
    if(typeof(Storage)!=='undefined'){
        console.log(sessionStorage.removeItem("firstname"));
        console.log(sessionStorage.removeItem("secondname"));

    }
}